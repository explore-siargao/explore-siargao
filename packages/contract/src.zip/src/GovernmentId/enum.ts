export enum E_GovernmentId {
  "DriversLicense" = "DriversLicense",
  "Passport" = "Passport",
  "NationalID" = "NationalID",
  "PostalID" = "PostalID",
}
