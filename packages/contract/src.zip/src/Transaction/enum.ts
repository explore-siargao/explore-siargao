export enum E_TransactionStatus {
  Succeed = "Succeed",
  Failed = "Failed",
  Pending = "Pending",
  Refunded = "Refunded",
}
