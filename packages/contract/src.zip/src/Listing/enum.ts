export enum E_PaymentType {
  GCASH = "GCASH",
  CreditDebit = "CreditDebit",
  SavedCreditDebit = "SavedCreditDebit",
}
