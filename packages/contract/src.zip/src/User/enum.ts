export enum E_UserRole {
  Admin = "Admin",
  Host = "Host",
  User = "User",
}

export enum E_RegistrationType {
  Manual = "Manual",
  Facebook = "Facebook",
  Google = "Google",
}
